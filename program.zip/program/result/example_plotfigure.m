

clear
clc
close all
load true.mat


load WOA_vmd_CNN_BiLSTM_Adaboost.mat
load VMD_CNNbiLSTM.mat
load VMDCNNBiLSTMAdaboost
load SSCSO_vmd_CNN_BiLSTM_Adaboost.mat
load SABO_vmd_CNN_BiLSTM_Adaboost.mat
load ELM_Adaboost.mat
load dbo_vmd_CNN_BiLSTM_Adaboost.mat


str={'True Value','SSCSO-VMD-CNN-BiLSTM-Adaboost','VMD-CNN-BiLSTM','VMD-CNN-BiLSTM-Adaboost','WOA-VMD-CNN-BiLSTM-Adaboost','SABO-VMD-CNN-BiLSTM-Adaboost','ELM-Adaboost','DBO-VMD-CNN-BiLSTM-Adaboost'};
figure('Units', 'pixels', ...
    'Position', [300 300 860 375]);
title('Comparison of Predictive Performance Across Models')
xlabel('Sample Point')
ylabel('Power Generation/MW')
plot(T_test2,'--*') 
hold on
plot(SSCSOVMDCNNBiLSTMAdaboost_TSIM2)
hold on
plot(VMDCNNBILSTM_TSIM2)
hold on
plot(VMDCNNBiLSTMAdaboost_TSIM2)
hold on
plot(WOAVMDCNNBiLSTMAdaboost_TSIM2)
hold on
plot(SABOVMDCNNBiLSTMAdaboost_TSIM2)
hold on
plot(ELM_Adaboost_TSIM2)
hold on
plot(DBOVMDCNNBiLSTMAdaboost_TSIM2)
legend(str)
set (gca,"FontSize",12,'LineWidth',1.2)
title('Comparison of Predictive Performance Across Models')
xlabel('Sample Point')
ylabel('Power Generation/MW')

box off
legend Box off


