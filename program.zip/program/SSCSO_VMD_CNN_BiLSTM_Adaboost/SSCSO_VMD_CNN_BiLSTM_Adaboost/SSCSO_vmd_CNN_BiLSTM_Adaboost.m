clc;
clear
close all
X = xlsread('..\data.xlsx');
X = X(5665:8640,:);  
load vmd_data.mat
IMF = u;
disp('…………………………………………………………………………………………………………………………')
disp(' SSCSO-VMD-CNN-BiLSTM-AdaBoost ')
disp('…………………………………………………………………………………………………………………………')


for uu=1:size(IMF,2)
    X_imf=[X(:,1:end-1),IMF(:,uu)];

    num_samples = length(X_imf);       
    kim = 3;                      
    zim =  1;                     
    or_dim = size(X_imf,2);

  
    for i = 1: num_samples - kim - zim + 1
        res(i, :) = [reshape(X_imf(i: i + kim - 1,:), 1, kim*or_dim), X_imf(i + kim + zim - 1,:)];
    end


    
    outdim = 1;                                  
    num_size = 0.7;                             
    num_train_s = round(num_size * num_samples); 
    f_ = size(res, 2) - outdim;                  


    P_train = res(1: num_train_s, 1: f_)';
    T_train = res(1: num_train_s, f_ + 1: end)';
    M = size(P_train, 2);

    P_test = res(num_train_s + 1: end, 1: f_)';
    T_test = res(num_train_s + 1: end, f_ + 1: end)';
    N = size(P_test, 2);

   
    [p_train, ps_input] = mapminmax(P_train, 0, 1);
    p_test = mapminmax('apply', P_test, ps_input);

    [t_train, ps_output] = mapminmax(T_train, 0, 1);
    t_test = mapminmax('apply', T_test, ps_output);

   

    for i = 1:size(P_train,2)
        trainD{i,:} = (reshape(p_train(:,i),size(p_train,1),1,1));
    end

    for i = 1:size(p_test,2)
        testD{i,:} = (reshape(p_test(:,i),size(p_test,1),1,1));
    end


    targetD =  t_train;
    targetD_test  =  t_test;

    numFeatures = size(p_train,1);


    layers0 = [ ...
        
        sequenceInputLayer([numFeatures,1,1],'name','input')  
        sequenceFoldingLayer('name','fold')        
        
        convolution2dLayer([3,1],16,'Stride',[1,1],'name','conv1') 
        batchNormalizationLayer('name','batchnorm1')  
        reluLayer('name','relu1')      
        
        maxPooling2dLayer([2,1],'Stride',2,'Padding','same','name','maxpool')   
     
        sequenceUnfoldingLayer('name','unfold')     
  
        flattenLayer('name','flatten')

        bilstmLayer(30,'Outputmode','last','name','hidden1')
        dropoutLayer(0.1,'name','dropout_1')        

        fullyConnectedLayer(1,'name','fullconnect')  
        regressionLayer('Name','output')    ];

    lgraph0 = layerGraph(layers0);
    lgraph0 = connectLayers(lgraph0,'fold/miniBatchSize','unfold/miniBatchSize');


   
    options0 = trainingOptions('adam', ...                
        'MaxEpochs', 50, ...                            
        'GradientThreshold', 1, ...                       
        'InitialLearnRate', 0.01, ...         
        'LearnRateSchedule', 'piecewise', ...            
        'LearnRateDropPeriod',30, ...                 
        'LearnRateDropFactor',0.01, ...                    
        'L2Regularization', 0.001, ...         
        'ExecutionEnvironment', 'cpu',...                 
        'Verbose', 1, ...                                
        'Plots', 'none');                    

    
    D = ones(1, M) / M;

    
    K = 2;                       


    
    for i = 1 : K
        i
        
        clear net
        net = trainNetwork(trainD,targetD',lgraph0,options0);
        result1 = predict(net, trainD);
        result2 =  predict(net, testD);
        
        E_sim1 = double(result1);
        E_sim2 = double(result2);

       
        t_sim1(i, :) = E_sim1';
        t_sim2(i, :) = E_sim2';

       
        Error(i, :) = t_sim1(i, :) - t_train;

        
        weight(i) = 0;
        for j = 1 : M
            if abs(Error(i, j)) > 0.02
                weight(i) = weight(i) + D(i, j);
                D(i + 1, j) = D(i, j) * 1.1;
            else
                D(i + 1, j) = D(i, j);
            end
        end

        
        weight(i) = 0.5 / exp(abs(weight(i)));

       
        D(i + 1, :) = D(i + 1, :) / sum(D(i + 1, :));

    end

    
    weight = weight / sum(weight);

    
    T_sim1 = zeros(1, M);
    T_sim2 = zeros(1, N);

    for i = 1 : K
        output1 = (weight(i) * t_sim1(i, :));
        output2 = (weight(i) * t_sim2(i, :));

        T_sim1 = output1 + T_sim1;
        T_sim2 = output2 + T_sim2;
    end

   
    T_sim1 = mapminmax('reverse', T_sim1, ps_output);
    T_sim2 = mapminmax('reverse', T_sim2, ps_output);



  
    imf_T_sim1(:,uu) = double(T_sim1);
    imf_T_sim2(:,uu) = double(T_sim2);
end

num_samples = length(X);       
or_dim = size(X,2);

for i = 1: num_samples - kim - zim + 1
    res(i, :) = [reshape(X(i: i + kim - 1,:), 1, kim*or_dim), X(i + kim + zim - 1,:)];
end

T_train = res(1: num_train_s, f_ + 1: end)';
T_test = res(num_train_s + 1: end, f_ + 1: end)';



T_sim_a = sum(imf_T_sim1,2);
T_sim_b = sum(imf_T_sim2,2);


SSCSOVMDCNNBiLSTMAdaboost_TSIM1 = T_sim_a';
SSCSOVMDCNNBiLSTMAdaboost_TSIM2 = T_sim_b';
save SSCSO_vmd_CNN_BiLSTM_Adaboost SSCSOVMDCNNBiLSTMAdaboost_TSIM1 SSCSOVMDCNNBiLSTMAdaboost_TSIM2


disp('…………Test set error indicator…………')
[mae1,rmse1,mape1,error1]=calc_error(T_train,T_sim_a');
fprintf('\n')

figure('Position',[200,300,600,200])
plot(T_train,'r-*','LineWidth',0.1,'MarkerSize',2);
hold on
plot(T_sim_a,'b-o','LineWidth',0.1,'MarkerSize',3)
legend('True value','Estimate')
title(' SSCSO-VMD-CNN-BiLSTM-AdaBoost Comparison of training set prediction performance')
xlabel('Sample points')
ylabel('Power generation/MW')

disp('…………Training set error index…………')
[mae2,rmse2,mape2,error2]=calc_error(T_test,T_sim_b');
fprintf('\n')


figure('Position',[200,300,1100,300])
plot(T_test,'r-*','LineWidth',0.1,'MarkerSize',2);
hold on
plot(T_sim_b,'b-o','LineWidth',0.1,'MarkerSize',3)
legend('True value','Estimate')
title(' SSCSO-VMD-CNN-BiLSTM-AdaBoost Comparison of prediction performance of prediction sets')
xlabel('Sample points')
ylabel('Power generation/MW')

figure('Position',[200,300,1100,300])
plot(T_sim_b'-T_test)
title('VMD-CNN-BiLSTM-Adaboost-Error curve chart')
xlabel('Sample points')
ylabel('Power generation/MW')