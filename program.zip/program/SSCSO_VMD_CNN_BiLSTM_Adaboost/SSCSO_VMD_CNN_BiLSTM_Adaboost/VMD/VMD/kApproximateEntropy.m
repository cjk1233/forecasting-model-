


function ApEn = kApproximateEntropy(data, dim, r)
，
data = data(:); 
N = length(data);
result = zeros(1,2);%
for j = 1:2
m = dim+j-1;
C = zeros(1,N-m+1);%，
dataMat = zeros (m, N-m+1);%
for i = 1:m
dataMat(i,:) = data(i:N-m+i); %
end
% counting similar patterns using distance calculation
for i = 1:N-m+1
tempMat = abs(dataMat - repmat (dataMat(:,i),1,N-m+1));
boolMat = any((tempMat>r),1);
C(i)=sum(~boolMat)/(N-m+1);
end
phi(j) = sum(log(C))/(N-m+1);
end
ApEn = phi(1)-phi(2);
end
