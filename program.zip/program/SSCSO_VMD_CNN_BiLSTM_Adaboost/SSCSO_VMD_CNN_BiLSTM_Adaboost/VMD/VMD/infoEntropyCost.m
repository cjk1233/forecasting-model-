

function [ff] = infoEntropyCost(c,data)
X = data;
alpha = fix(c(1));      
K = fix(c(2));               
%--------------- Run actual VMD code:vmd---------------------------
[u, u_hat, omega] = vmd(X,'PenaltyFactor', alpha,'NumIMF',K);
u=u';
for i = 1:K
    fitness(i,:) = entropy(u(i,:));  
end
[ff] = min(fitness);
end





