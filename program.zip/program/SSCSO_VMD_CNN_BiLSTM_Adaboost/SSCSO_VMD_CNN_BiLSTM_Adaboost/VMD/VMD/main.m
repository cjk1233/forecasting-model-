
clear
clc
close all


data = xlsread('data.xlsx'); 
data = data(5665:8640,end);  

xz = 4;  
。
if xz == 1  
    fobj=@(x)EnvelopeEntropyCost(x,data);         
elseif xz == 2
    fobj=@(x)SampleEntropyCost(x,data);            
elseif xz == 3  
    fobj=@(x)infoEntropyCost(x,data);              
elseif xz == 4
    fobj=@(x)PermutationEntropyCost(x,data);       
elseif xz == 5
    fobj=@(x)compositeEntropyCost(x,data);       
end



lb = [100 3];    
ub = [2500 8];  
dim = 2;            
Max_iter=15;       
SearchAgents_no=5;      

[GTO_bestfit, SSCSO_bestX, SSCSO_Convergence_curve] = SSCSO(SearchAgents_no,Max_iter,lb,ub,dim,fobj);


figure
plot(SSCSO_Convergence_curve,'Color',[0.9 0.5 0.1],'Marker','>','LineStyle','--','linewidth',1);

title('Objective space')
xlabel('Iteration');
ylabel('Best score obtained so far');
legend('SSCSO VMD')
display(['The best solution obtained by SSCSO is : ', num2str(fix(SSCSO_bestX))]);  
display(['The best optimal value of the objective funciton found by SSCSO is : ', num2str(GTO_bestfit)]);  



u = vmd(data,'NumIMFs',fix(SSCSO_bestX(2)),'PenaltyFactor',fix(SSCSO_bestX(1)));
save vmd_data u








