clc
clear
load vmd_data.mat
fs=4;
Ts=1/fs;
STA=1; 
%------------------------------------------------------
X = xlsread('data.xlsx');
X = X(5665:8640,end);  
L=length(X);
t=(0:L-1)*Ts;

u = u';
K = size(u,1);
figure(1);
imfn=u;
n=size(imfn,1);
subplot(n+1,1,1);
plot(t,X); 
ylabel('original signal ','fontsize',12,'fontname','宋体');

for n1=1:n
    subplot(n+1,1,n1+1);
    plot(t,u(n1,:));
    ylabel(['IMF' int2str(n1)]);
end
xlabel('time\itt/h','fontsize',12,'fontname',);

figure
for i = 1:K
    Hy(i,:)= abs(hilbert(u(i,:)));
    subplot(K,1,i);
    plot(t,u(i,:),'k',t,Hy(i,:),'r');
    xlabel('Sample point'); ylabel('amplitude')
    grid; legend('Signal',' envelope');
end
title('Signal and envelope');
set(gcf,'color','w');




figure('Name','Envelope spectrum','Color','white');
nfft=fix(L/2);
for i = 1:K
    Hy(i,:)= abs(hilbert(u(i,:)));
    p=abs(fft(Hy(i,:))); 
    p = p/length(p)*2;
    p = p(1: fix(length(p)/2));
    subplot(K,1,i);
    plot((0:nfft-1)/nfft*fs/2,p)   
    xlim([0.01 0.14]) 
    if i ==1
        title('Envelope spectrum'); xlabel('frequency'); ylabel('amplitude')
    else
        xlabel('frequency'); ylabel('amplitude')
    end
end
set(gcf,'color','w');


figure('Name','Spectrogram','Color','white');
for i = 1:K
    p=abs(fft(u(i,:)));
    subplot(K,1,i);
    plot((0:L-1)*fs/L,p)
    xlim([0 fs/2])
    if i ==1
        title('frequency'); xlabel('frequency'); ylabel(['IMF' int2str(i)]);
    else
        xlabel('frequency');  ylabel(['IMF' int2str(i)]);
    end
end
set(gcf,'color','w');




for i=1:K
    a(i)=kurtosis(imfn(i,:));
    disp(['IMF',num2str(i),'Kurtosis',num2str(a(i))])
end
figure
b = bar(a,0.3);
xlabel('Modal function'); ylabel('Kurtosis value')
set(gca,'xtick',1:1:K);
set(gca,'xticklabel',{'IMF1','IMF2','IMF3','IMF4','IMF5','IMF6','IMF7','IMF8'});
xtips1 = 1:1:K;
ytips1 = a;
for jj=1:K
    labels1(jj) = string(a(jj)); 
end
text(xtips1, ytips1, labels1, 'HorizontalAlignment', 'center', 'VerticalAlignment', 'bottom');


for i=1:K
    Eimf(i) = sum(imfn(i,:).^2,2);
end
disp(['IMFEnergy of components'])
disp(Eimf(1:K))

E = sum(Eimf);
for j = 1:K
    p(j) = Eimf(j)/E;
    HE(j)=-sum(p(j).*log(p(j)));
end
disp('EMDEnergy entropy=%.4f');
disp(HE(1:K));




for i1=1:K
    imf0=imfn(i1,:);%
    x=imf0';
    ApEnx = kApproximateEntropy(x, 2, 0.15);   
    ApEn(1,i1)= ApEnx;
    disp(['IMF',num2str(i1),'approximate entropy of is:',num2str(ApEn(1,i1))])
endThe 



for i = 1:K
    xx= abs(hilbert(u(i,:))); 
    xxx = xx/sum(xx);
    ssum=0;
    for ii = 1:size(xxx,2)
        bb = xxx(1,ii)*log(xxx(1,ii));
        ssum=ssum+bb;
    end
    Enen(i,:) = -ssum;
    disp(['IMF',num2str(i),'The envelope entropy of is:',num2str(Enen(i,:))])
end
ff = min(Enen);
disp(['The local minimum envelope entropy is:',num2str(ff)])


figure('Name','Spectrogram','Color','white');
for i = 1:K
    p=abs(fft(u(i,:)));
    subplot(K,1,i);
    plot((0:L-1)*fs/L,p)
    xlim([0 fs/2])
    if i ==1
        title('Spectrogram'); xlabel('frequency'); ylabel(['IMF' int2str(i)]);%int2str(i)是将数值i四舍五入后转变成字符，y轴命名
    else
        xlabel('frequency');  ylabel(['IMF' int2str(i)]);%int2str(i)是将数值i四舍五入后转变成字符，y轴命名
    end
end
set(gcf,'color','w');



r0=0.15;   
for i1=1:K
    imf0=imfn(i1,:);%
    x=imf0;
    r=r0*std(x);
    FuEnx = FuzzyEntropy(x, 6, r,2,1);   
    FuEn(1,i1)= FuEnx;
    disp(['IMF',num2str(i1),'The fuzzy entropy of is:',num2str(FuEn(1,i1))])
end


M = 3;  
T = 1;  
for i1=1:K
    imf0=imfn(i1,:);%
    x=imf0;
    PerEnx = PermutationEntropy(x,M,T);   
    PerEn(1,i1)= PerEnx;
    disp(['IMF',num2str(i1),'The permutation entropy of is：',num2str(PerEn(1,i1))])
end


m = 6;          %m: order of permuation entropy;
t = 1;          %t: delay time of permuation entropy;
scale = 30;     %scale: the scale factor;
for i1=1:K
    imf0=imfn(i1,:);%
    x=imf0';
    MPE = MultiscalePermutationEntropy(x,m,t,scale);   
    B(i1,:)= MPE;
end
disp('The entropy of multi-scale arrangement is：')
disp(num2str(B))


dim = 2;   
tau = 1;   
for i1=1:K
    imf0=imfn(i1,:);%
    x=imf0;
    r = 0.2*std(x);  %   
    SaEnx = SampleEntropy(dim,r, x, tau);    
    SaEn(1,i1)= SaEnx;
    disp(['IMF',num2str(i1),'The sample entropy of is：',num2str(SaEn(1,i1))])
end


