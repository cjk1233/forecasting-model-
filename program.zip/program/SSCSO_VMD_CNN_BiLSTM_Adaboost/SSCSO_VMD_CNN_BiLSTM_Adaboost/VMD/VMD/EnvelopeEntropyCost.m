
function [ff] = EnvelopeEntropyCost(c,data)
X = data;
alpha = fix(c(1));      
K = fix(c(2));               
%--------------- Run actual VMD code:vmd---------------------------
[u, u_hat, omega] = vmd(X,'PenaltyFactor', alpha,'NumIMF',K);
u=u';
for i = 1:K
	xx= abs(hilbert(u(i,:))); 
	xxx = xx/sum(xx);
    ssum=0;
	for ii = 1:size(xxx,2)
		bb = xxx(1,ii)*log(xxx(1,ii));
        ssum=ssum+bb;
    end
    fitness(i,:) = -ssum;
end
[ff] = min(fitness);
end


