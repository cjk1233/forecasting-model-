

function [ff] = compositeEntropyCost(c,data)

X = data;
alpha = fix(c(1));       
K = fix(c(2));                 
%--------------- Run actual VMD code:vmd--------------------------
[u, u_hat, omega] = vmd(X,'PenaltyFactor', alpha,'NumIMF',K);
u=u';
M = 3;  
T = 1;  
for i = 1:K
    fitness1 = PermutationEntropy(u(i,:),M,T);  
    fitness2 = calmi(u(i,:)',X);  
    fitness(i) = fitness1/fitness2;
end
[ff] = min(fitness);
end




function mi = calmi(u1, u2)
x = [u1, u2];
n = length(u1);
[xrow, xcol] = size(x);
bin = zeros(xrow,xcol);
pmf = zeros(n, 2);
for i = 1:2
    minx = min(x(:,i));
    maxx = max(x(:,i));
    binwidth = (maxx - minx) / n;
    edges = minx + binwidth*(0:n);
    histcEdges = [-Inf edges(2:end-1) Inf];
    [occur,bin(:,i)] = histc(x(:,i),histcEdges,1); 
    pmf(:,i) = occur(1:n)./xrow;
end

jointOccur = accumarray(bin,1,[n,n]); 
jointPmf = jointOccur./xrow;
Hx = -(pmf(:,1))'*log2(pmf(:,1)+eps);
Hy = -(pmf(:,2))'*log2(pmf(:,2)+eps);
Hxy = -(jointPmf(:))'*log2(jointPmf(:)+eps);
MI = Hx+Hy-Hxy;
mi = MI/sqrt(Hx*Hy);
end





function [pe ,hist] = PermutationEntropy(y,m,t)

%  Calculate the permutation entropy(PE)
%  Bandt C，Pompe B. Permutation entropy:a natural complexity measure for time series[J]. Physical Review Letters,2002,88(17):174102.

%  Input:   y: time series;
%           m: order of permuation entropy 
%           t: delay time of permuation entropy,

% Output: 
%           pe:    permuation entropy
%           hist:  the histogram for the order distribution
ly = length(y);
permlist = perms(1:m);
[h,~]=size(permlist);
c(1:length(permlist))=0;

 for j=1:ly-t*(m-1)
     [~,iv]=sort(y(j:t:j+t*(m-1)));
     for jj=1:h
         if (abs(permlist(jj,:)-iv))==0
             c(jj) = c(jj) + 1 ;
         end
     end
 end
hist = c;
c=c(c~=0);
p = c/sum(c);
pe = -sum(p .* log(p));

pe=pe/log(factorial(m));
end
