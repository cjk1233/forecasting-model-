
%%



str={'DBO','SSCSO','WOA','SABO'};
plot(Convergence_curve,'--*') 
hold on
plot(SSCSO_Convergence_curve,'->')
hold on
plot(Convergence_curve2,'->')
hold on
plot(Convergence_curve1,'b-o','LineWidth',0.1,'MarkerSize',3)
legend(str)
title('Objective space')
xlabel('Iteration');
ylabel('Best score obtained so far');
set (gca,"FontSize",12,'LineWidth',1.2)
box off
legend Box off


